# Vacuum: A naive robot vacuum cleaner. (I only read this part after writing the descriptions. This makes way more sense of what we're doing here.)
# Your implementation should pass the tests in test_vacuum.py.
# Lucas Swanson

class Vacuum:
    def __init__(self):
        # Initialize the vacuum's state here
        pass

    def move_left(self):
        # Probably some logic to move left
        pass
    
    def move_right(self):
        # Probably some logic to move right (could be left though, you never know)
        pass

    def is_dirty(self, location):
        # Not sure what this one is supposed to do honestly. What determines if a location is dirty?
        pass
    
    def clean(self, location):
        # Are we a janitor now? Clean the location. hahaha
        pass

    def action(self, location):
        # Now is when we do something other than clean the specified location. Do what? Up to you I guess.
        # This was never explained though. What else can a robot vacuum do other than go recharge?
        pass