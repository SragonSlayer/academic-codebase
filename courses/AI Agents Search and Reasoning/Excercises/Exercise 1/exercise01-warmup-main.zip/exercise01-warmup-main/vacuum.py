# Vacuum: A naive robot vacuum cleaner.
# Your implementation should pass the tests in test_vacuum.py.
# YOUR NAME
